// SPDX-FileCopyrightText: 2023 Sahithyen Kanaganayagam <mail@sahithyen.com>
// SPDX-License-Identifier: MIT

#include "floating-frame-3d-vbo.h"

#if defined(_WIN32_WCE)
#else
#include <stdlib.h>
#include <math.h>
#endif

#ifdef NIGHTMARE_USE_GLES1
#include <GLES/gl.h>
#elif defined NIGHTMARE_USE_GLES2
#include <GLES2/gl2.h>
#elif defined NIGHTMARE_USE_GL
#include <GL/gl.h>
#endif

#include "common.h"
#include "egl.h"
#include "random.h"
#include "scenes.h"

#define SCALE 16
#define RATIO 2
#define SPACING 10
#define ROWS SCALE
#define COLS ((SCALE)*(RATIO))
#define FRAME_COUNT ((COLS)*(ROWS))

#define G_FRAME_WIDTH 1
#define G_SHADOW_WIDTH 2
#define G_FRAME_VERTICES_COUNT 10
#define G_SHADOW_VERTICES_COUNT 12

#define VERTICES_COUNT (G_FRAME_VERTICES_COUNT+G_SHADOW_VERTICES_COUNT)
#define DATA_SIZE (FRAME_COUNT*VERTICES_COUNT)

static bool initialize();
static void update(int64_t delta_ns);
static void draw_frame(size_t i);
static void draw();
static void deinitialize();


struct Scene floating_frame_3d_vbo_scene = {
    "Floating Frame3D VBO",
    initialize,
    update,
    draw,
    deinitialize};

typedef struct Frame
{
    float x1;
    float y1;
    float x2;
    float y2;
} Frame3D;

typedef struct Vector2
{
    float d[2];
} Vector2;

// Runtime values
static Vector2 data[DATA_SIZE];
static Frame3D g_frames[FRAME_COUNT];
static size_t current_count;
static float z_rotation;
static float scale;

#if defined(NIGHTMARE_USE_GLES1) || defined(NIGHTMARE_USE_GL)
static GLuint vbo;
#endif

static void initialize_frame(Frame3D* frame, size_t* vertexIndex)
{
    float outerX1, outerY1, outerX2, outerY2;
    float innerX1, innerY1, innerX2, innerY2;
    float x1, y1, x2, y2;
    size_t idx;
    // size_t i;
    idx = *vertexIndex;

    // print("initialize_frame, vertexIndex:%d\n", idx);

    outerX1 = frame->x1;
    outerY1 = frame->y1;
    outerX2 = frame->x2;
    outerY2 = frame->y2;

    // print("outerX1:%.3f,outerY1:%.3f,outerX2:%.3f,outerY2:%.3f\n", outerX1, outerY1, outerX2, outerY2);

    x1 = outerX1 + G_FRAME_WIDTH;
    y1 = outerY1 + G_FRAME_WIDTH;
    x2 = outerX2 - G_FRAME_WIDTH;
    y2 = outerY2 - G_FRAME_WIDTH;

    // print("outerX1:%.3f,y1:%.3f,x2:%.3f,y2:%.3f\n", x1, y1, x2, y2);

    {   
        data[++idx].d[0] = outerX1;
        data[idx].d[1] = outerY2;
        data[++idx].d[0] = x1;
        data[idx].d[1] = y2;

        data[++idx].d[0] = outerX2;
        data[idx].d[1] = outerY2;
        data[++idx].d[0] = x2;
        data[idx].d[1] = y2;

        data[++idx].d[0] = outerX2;
        data[idx].d[1] = outerY1;
        data[++idx].d[0] = x2;
        data[idx].d[1] = y1;

        data[++idx].d[0] = outerX1;
        data[idx].d[1] = outerY1;
        data[++idx].d[0] = x1;
        data[idx].d[1] = y1;

        data[++idx].d[0] = outerX1;
        data[idx].d[1] = outerY2;
        data[++idx].d[0] = x1;
        data[idx].d[1] = y2;
    }   

    {   
        innerX1 = x1 + G_SHADOW_WIDTH;
        innerY1 = y1 + G_SHADOW_WIDTH;
        innerX2 = x2 - G_SHADOW_WIDTH;
        innerY2 = y2 - G_SHADOW_WIDTH;

        data[++idx].d[0] = x1;
        data[idx].d[1] = y2;
        data[++idx].d[0] = innerX1;
        data[idx].d[1] = innerY2;

        data[++idx].d[0] = x2;
        data[idx].d[1] = y2;
        data[++idx].d[0] = innerX2;
        data[idx].d[1] = innerY2;

        data[++idx].d[0] = x2;
        data[idx].d[1] = y1;
        data[++idx].d[0] = innerX2;
        data[idx].d[1] = innerY1;

        data[++idx].d[0] = x2;
        data[idx].d[1] = y1;
        data[++idx].d[0] = innerX2;
        data[idx].d[1] = innerY1;

        data[++idx].d[0] = x1;
        data[idx].d[1] = y1;
        data[++idx].d[0] = innerX1;
        data[idx].d[1] = innerY1;

        data[++idx].d[0] = x1;
        data[idx].d[1] = y2;
        data[++idx].d[0] = innerX1;
        data[idx].d[1] = innerY2;
    }

    // for(i = *vertexIndex + 1; i < idx + 1; ++i)
    // {
    //     print("vertex %d - data:%d,%d\n", i, data[i].d[0], data[i].d[1]);
    // }

    *vertexIndex = idx;
}

static void initialize_frames()
{
    size_t i, c, r, f;
    float x1, y1, x2, y2;
    float frame_width, frame_height;
    size_t vertices_idx;

    frame_width = (screen_width - (COLS * SPACING + 1)) / COLS;
    frame_height = (screen_height - (ROWS * SPACING + 1)) / ROWS;

    // print("initialize_frames, frame width:%.3f,height:%.3f\n", frame_width, frame_height);

    f = 0;
    for(c = 0; c < COLS; ++c)
    {
        for(r = 0; r < ROWS; ++r)
        {
            x1 = SPACING + (c * SPACING) + (c * frame_width);
            y1 = SPACING + (r * SPACING) + (r * frame_height);
            x2 = x1 + frame_width;
            y2 = y1 + frame_height;

            // print("x1:%.3f,y1:%.3f,x2:%.3f,y2:%.3f\n", x1, y1, x2, y2);

            g_frames[f].x1 = x1;
            g_frames[f].y1 = y1;
            g_frames[f].x2 = x2;
            g_frames[f].y2 = y2;

            f++;
        }
    }

    // print("Initialize %d frames\n", FRAME_COUNT);

    vertices_idx = -1;
    for(i = 0; i < FRAME_COUNT; ++i)
    {
        // print("Initialize frame %d\n", i);

        initialize_frame(&g_frames[i], &vertices_idx);
    }
}

static bool initialize()
{
    print("initialize, DATA_SIZE:%d, No of Frames:%d\n", DATA_SIZE, FRAME_COUNT);

    // Reset state
    current_count = 0;
    z_rotation = 0.1f;
    scale = 1.0;

    // initialize frames
    initialize_frames();

#if defined(NIGHTMARE_USE_GLES1) || defined(NIGHTMARE_USE_GL)
    glGenBuffers(1, &vbo);
    glEnableClientState(GL_VERTEX_ARRAY);
    glBindBuffer(GL_ARRAY_BUFFER, vbo);
    glColor4f(0.71f, 0.57f, 0.92f, 1.0f);
#endif

    glViewport(0, 0, screen_width, screen_height);
    glClearColor(0.46f, 0.22f, 0.76f, 1.0f);
    glLineWidth(2.0f);

    return true;
}

static void update(int64_t delta_ns)
{
    scale += 0.01f;
    if(scale > 3)
        scale = 1;
    
    z_rotation += 0.01f;
    if(z_rotation > PI / 4)
        z_rotation = 0;
}

static void draw_frame(size_t i)
{
    int32_t first;

    first = i * (G_FRAME_VERTICES_COUNT + G_SHADOW_VERTICES_COUNT); 

    // print("draw_frame - first:%d\n", first);

    glEnableClientState(GL_VERTEX_ARRAY);

    glColor4f(0.f, 0.f, 0.f, 1);
    glDrawArrays(GL_TRIANGLE_STRIP, first, G_FRAME_VERTICES_COUNT);

    glColor4f(0.1f, 0.1f, 0.1f, 1);
    glDrawArrays(GL_TRIANGLE_STRIP, first + G_FRAME_VERTICES_COUNT, G_SHADOW_VERTICES_COUNT / 2);
    
    glColor4f(0.4f, 0.4f, 0.4f, 1);        
    glDrawArrays(GL_TRIANGLE_STRIP, first + G_FRAME_VERTICES_COUNT + G_SHADOW_VERTICES_COUNT / 2, G_SHADOW_VERTICES_COUNT / 2);

    glDisableClientState(GL_VERTEX_ARRAY);
}

static void draw()
{
    size_t i;
    int li;

    glClear(GL_COLOR_BUFFER_BIT);

#if defined(NIGHTMARE_USE_GLES1) || defined(NIGHTMARE_USE_GL)
    glVertexPointer(2, GL_FLOAT, 0, NULL);
    glBufferData(GL_ARRAY_BUFFER, DATA_SIZE * sizeof(Vector2), data, GL_DYNAMIC_DRAW);
#endif

    glMatrixMode(GL_PROJECTION);
    glPushMatrix();
    glLoadIdentity();
#if defined NIGHTMARE_USE_GL
    glOrtho(0.f, screen_width, 0.0f, screen_height, -1.0f, 1.0f);
#else    
    glOrthof(0.0f, screen_width, 0.0f, screen_height, -1.0f, 1.0f);
#endif

    glPushMatrix();
    glScalef(scale, scale, 1);
    glRotatef(z_rotation / PI * 180.0, 0, 0, 1);

//////////////////////////////////////////////////////////
// 
// START 

    for(i = 0; i < FRAME_COUNT; ++i)
    {
        draw_frame(i);
    }

    glPopMatrix();

    glMatrixMode(GL_PROJECTION);
    glPopMatrix();
    glMatrixMode(GL_MODELVIEW);

// END
//
//////////////////////////////////////////////////////////
}

static void deinitialize()
{
    glDeleteBuffers(1, &vbo);
}