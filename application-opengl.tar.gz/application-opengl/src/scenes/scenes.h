// SPDX-FileCopyrightText: 2023 Sahithyen Kanaganayagam <mail@sahithyen.com>
// SPDX-License-Identifier: MIT

#pragma once

#include "common.h"

struct Scene
{
    const char *name;
    bool (*initialize)();
    void (*update)(int64_t delta_ns);
    void (*draw)();
    void (*deinitialize)();
};

bool run_scenes();
