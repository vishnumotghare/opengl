// SPDX-FileCopyrightText: 2023 Sahithyen Kanaganayagam <mail@sahithyen.com>
// SPDX-License-Identifier: MIT

#include "scenes.h"

#if defined(_WIN32_WCE)
// #include <Windows.h>
#endif

// #include <time.h>
#include "common.h"
#include "floating-graph.h"
#include "fixed-graph.h"
#include "floating-frame-3d.h"
#include "floating-frame-3d-vbo.h"
#include "fixed-frame-3d.h"
#include "signal-handler.h"
#include "egl.h"

#if defined(NIGHTMARE_USE_GL)    
size_t scenes_count = 3;
#else
size_t scenes_count = 5;
#endif

struct Scene *scenes[] = {
    &floating_frame_3d_vbo_scene,
    &floating_frame_3d_scene,
#if !defined(NIGHTMARE_USE_GL)    
    &fixed_frame_3d_scene,
#endif
    &floating_graph_scene,
#if !defined(NIGHTMARE_USE_GL)
    &fixed_graph_scene
#endif
};

static bool run_scene(struct Scene *scene);

bool run_scenes()
{
    size_t i;
    for (i = 0; i < scenes_count; i++)
    {
        if (!run_scene(scenes[i]))
        {
            return false;
        }
        else if (sigint_triggered)
        {
            return true;
        }
    }

    return true;
}

static bool run_scene(struct Scene *scene)
{
#if defined(__linux__)
    struct timespec stopped, started, last, current;
#else
    uint64_t stopped, started, last, current;
#endif
    uint64_t frames;
    int64_t delta_ns;
    double elapsed_time, fps;

    print("run scene '%s'\n", scene->name);

    if (!scene->initialize())
    {
        print_error("Failed to initialize EGL\n");
        return false;
    }

#if defined(__linux__)
    clock_gettime(CLOCK_MONOTONIC, &started);
    last = started;
#else
    started = GetTickCount();
    last = started;
#endif
    frames = 0;

    // Mainloop
    while (true)
    {
        if (difftimespec_ns(last, started) >= 15 * SEC_IN_NS)
            break;

        frames++;

        // Check SIGINT
        if (sigint_triggered)
        {
            goto finish;
        }

        // Run any EGL specific mainloop tasks
        egl_loop_step();

        // Calculate time delta
#if defined(__linux__)
        clock_gettime(CLOCK_MONOTONIC, &current);
#else
        current = GetTickCount();
#endif
        delta_ns = difftimespec_ns(current, last);
        last = current;

        // Update scene
        scene->update(delta_ns);

        // Draw scene
        scene->draw();
        eglSwapBuffers(egl_display, egl_surface);
    }

#if defined(__linux__)
    clock_gettime(CLOCK_MONOTONIC, &stopped);
#else
    stopped = GetTickCount();
#endif

    elapsed_time = ((double)difftimespec_ns(stopped, started)) / 1e9;
    fps = ((double)frames) / elapsed_time;

    print("Average FPS = %f\n", fps);
    print("---\n\n");

finish:
    scene->deinitialize();
    return true;
}