// SPDX-FileCopyrightText: 2023 Sahithyen Kanaganayagam <mail@sahithyen.com>
// SPDX-License-Identifier: MIT

#include "egl.h"

#if defined(_WIN32_WCE)
#pragma message("_WIN32_WCE")
#include <Windows.h>
#include <windowsx.h>
#include <commctrl.h>
#else 
#include <stdlib.h>
#include <string.h>
#endif

#include <EGL/egl.h>
#include <EGL/eglext.h>

#include "common.h"

/**
 * EGL/X11
 */

HWND g_window;
CRITICAL_SECTION g_critical_section;

int egl_major = -1;
int egl_minor = -1;
EGLDisplay egl_display;
EGLSurface egl_surface;

int screen_width = 1024;
int screen_height = 600;

#ifdef NIGHTMARE_USE_GLES1
    EGLint context_attributes[] = {
        EGL_CONTEXT_CLIENT_VERSION, 1,
        EGL_NONE};
#elif defined NIGHTMARE_USE_GLES2
    EGLint context_attributes[] = {
        EGL_CONTEXT_CLIENT_VERSION, 2,
        EGL_NONE};
#endif


struct CreateIntermediate
{
    WORD  idMenu;
    void* pCreateParams;
};

void
AdjustDisplayOrientation()
{
    DEVMODE devMode = { 0 };
    devMode.dmFields = DM_DISPLAYQUERYORIENTATION;

    ChangeDisplaySettingsEx( NULL, &devMode, NULL, CDS_TEST, NULL );

    if ( devMode.dmDisplayOrientation > DMDO_0 ) {
        devMode.dmFields = DM_DISPLAYORIENTATION;
        devMode.dmDisplayOrientation = DMDO_90;
        ChangeDisplaySettingsEx( NULL, &devMode, NULL, CDS_RESET, NULL );
    }
}

LRESULT
CALLBACK WorkerWindowProc(HWND   hWnd,
                          UINT   message,
                          WPARAM wParam,
                          LPARAM lParam)
{
    switch( message ) {
        case WM_CREATE:
        {
            CREATESTRUCTW* pCreateStruct = (CREATESTRUCTW*)lParam;
#if defined(_WIN32_WCE)
                HWND cmhwnd = CommandBar_Create(pCreateStruct->hInstance, hWnd, 1);
                CommandBar_InsertMenubar(cmhwnd, pCreateStruct->hInstance, 0, 0);
#endif
            return DefWindowProc(hWnd, WM_CREATE, 0, (LPARAM)(&pCreateStruct));
        }
        case WM_DESTROY:
        {
            PostQuitMessage(0);
#if defined(UNDER_CE)
            // if( pInstance->m_hCmdBar )
            //     pInstance->m_hCmdBar.DestroyWindow();
#endif
            return 0;
        }
        case WM_PAINT:
        {
            RECT rect;
            if( GetUpdateRect(hWnd, &rect, false) ) 
            {
                PAINTSTRUCT ps;
                HDC hdc = BeginPaint(hWnd, &ps);
                EndPaint(hWnd, &ps);
            }
            return 0;
        }
        default:
            return DefWindowProc(hWnd, message, wParam, lParam);
    }

    return 0;
}

LRESULT
CALLBACK CreateWindowProc(HWND   hWnd,
                          UINT   message,
                          WPARAM wParam,
                          LPARAM lParam)
{
    // print("CreateWindowProc\n");
    LeaveCriticalSection(&g_critical_section);
    SetWindowLongW(hWnd, GWL_WNDPROC,  (LONG)WorkerWindowProc);
    return WorkerWindowProc(hWnd, message, wParam, lParam);
}

bool initialize_window()
{
    HINSTANCE instance;
    WNDCLASS wc;
    HMONITOR hMonitor;
    MONITORINFO mi;
    LONG windowLong;
    int sw, sh;
    RECT rect;

    print("Initialize Window Information");
    print("-----------------------\n");

    // get the instance
    instance = GetModuleHandle(NULL);

    InitializeCriticalSection(&g_critical_section);

    wc.style         = CS_HREDRAW | CS_VREDRAW;
    wc.lpfnWndProc   = &CreateWindowProc;
    wc.cbClsExtra    = 0;
    wc.cbWndExtra    = 0;
    wc.hInstance     = instance;
    wc.hIcon         = NULL;
    wc.hCursor       = LoadCursor(0, IDC_ARROW);
    wc.hbrBackground = (HBRUSH)(COLOR_WINDOW + 1);
    wc.lpszMenuName  = NULL;
    wc.lpszClassName = L"GalileoMark";

    if( !RegisterClass(&wc) )
    {
        print_error("RegisterClassW Failed\n");
        return false;
    }

    EnterCriticalSection(&g_critical_section);

    g_window = CreateWindowExW(
                0,
                wc.lpszClassName,
                L"Galileo Mark",
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                instance,
                NULL);

    AdjustDisplayOrientation();

    ShowWindow(g_window, SW_SHOWNORMAL);
    UpdateWindow(g_window);

    SetForegroundWindow(g_window);
    SetActiveWindow(g_window);

    windowLong = GetWindowLong(g_window, GWL_STYLE);
    if(windowLong & WS_CAPTION)
    {
        print("Has a title bar - removing it...\n");
        windowLong &= ~WS_CAPTION;
        SetWindowLong(g_window, GWL_STYLE, windowLong);
        SetWindowPos(g_window, 0, 0, 0, 0, 0, SWP_NOSIZE | SWP_NOMOVE | SWP_NOZORDER | SWP_NOACTIVATE | SWP_DRAWFRAME);
    }

    sw = GetSystemMetrics(SM_CXSCREEN);
    sh = GetSystemMetrics(SM_CYSCREEN);

    // Find the right monitor to do the fullscreen
    GetWindowRect( g_window, &rect );
    hMonitor = MonitorFromRect( &rect, MONITOR_DEFAULTTONEAREST );
    
    mi.cbSize = sizeof(mi);
    GetMonitorInfo( hMonitor, &mi );

    print("SM_CXSCREEN:%d, SM_CYSCREEN:%d\n", sw, sh);
    print("mi.rcMonitor.left:%d, mi.rcMonitor.top:%d\n", mi.rcMonitor.left, mi.rcMonitor.top);
    print(" ");

    SetWindowPos( g_window, HWND_TOP, mi.rcMonitor.left, mi.rcMonitor.top, sw, sh, SWP_SHOWWINDOW );

    return g_window != NULL;
}

bool initialize_egl()
{
    const EGLint attribute_list[] = {
        EGL_RED_SIZE, 8,
        EGL_GREEN_SIZE, 8,
        EGL_BLUE_SIZE, 8,
        EGL_ALPHA_SIZE, 8,
        EGL_RENDERABLE_TYPE,
#ifdef NIGHTMARE_USE_GLES1
    EGL_OPENGL_ES_BIT,
#elif defined NIGHTMARE_USE_GLES2
    EGL_OPENGL_ES2_BIT,
#endif
        EGL_NONE};

    NativeDisplayType display;
    EGLBoolean egl_success;
    EGLint found_configs;
    EGLint config_count;
    EGLConfig *configs;
    EGLConfig egl_config;
    EGLint config_id;
    EGLint native_id;
    EGLContext egl_context;

    if (!initialize_window())
    {
        DWORD err = GetLastError();
        print_error("Failed to create and initialize the g_window, error code: %d\n", err);
        return false;
    }

    if(g_window == NULL)
    {
        print_error("this should not happen\n");
        return false;
    }

    // Cast to have the display
    display = ( NativeDisplayType ) GetDC( g_window );

    if (!display)
    {
        print_error("Could not get the display\n");
        return false;
    }

    egl_display = eglGetDisplay(display);

    // Initialize EGL
    egl_success = eglInitialize(egl_display, &egl_major, &egl_minor);

    if (!egl_success)
    {
        print_error("Could not initialize EGL\n");
        return false;
    }

    // Get number of matching framebuffer configurations
    found_configs = 0;
    egl_success = eglChooseConfig(egl_display, attribute_list, NULL, 0, &found_configs);
    if (!egl_success || found_configs == 0)
    {
        print_error("Failed to query framebuffer configurations\n");
        return false;
    }
    else if (found_configs == 0)
    {
        print_error("No supported framebuffer configurations found\n");
        return false;
    }

    // http://directx.com/2014/06/egl-understanding-eglchooseconfig-then-ignoring-it/

    // Get matching framebuffer configurations
    config_count = found_configs;
    configs = (EGLConfig *)calloc(sizeof(EGLConfig), (size_t)config_count);
    egl_success = eglChooseConfig(egl_display, attribute_list, configs, config_count, &found_configs);
    if (!egl_success)
    {
        free(configs);
        print_error("Could not retrieve matched framebuffer configurations\n");
        return false;
    }
    else if (config_count != found_configs)
    {
        free(configs);
        print_error("Different counts of supported framebuffer configurations after back to back call\n");
        return false;
    }

    // Choose framebuffer configuration
    // TODO: currently selecting the first result. selecting the one with the least capabilities would be better
    egl_config = configs[0];
    config_id = 0;
    if (!eglGetConfigAttrib(egl_display, egl_config, EGL_CONFIG_ID, &config_id))
    {
        free(configs);
        print_error("Could not retrieve id from framebuffer configuration\n");
        return false;
    }

    native_id;
    if (!eglGetConfigAttrib(egl_display, egl_config, EGL_NATIVE_VISUAL_ID, &native_id))
    {
        free(configs);
        print_error("Could not retrieve X11 id from framebuffer configuration\n");
        return false;
    }

    free(configs);

    // Create EGL surface
    egl_surface = eglCreateWindowSurface(egl_display, egl_config, (EGLNativeWindowType)g_window, NULL);
    if (!egl_surface)
    {
        print_error("Could not create EGL surface (error code: %x)\n", eglGetError());
        return false;
    }

    // Create context
    egl_context = eglCreateContext(egl_display, egl_config,
                                              EGL_NO_CONTEXT, context_attributes);

    // Make current
    egl_success = eglMakeCurrent(egl_display, egl_surface, egl_surface, egl_context);
    if (!egl_success)
    {
        print_error("Could not set EGL context as current one (error code: %x)\n", eglGetError());
        return false;
    }

    // Set zero time swapping
    egl_success = eglSwapInterval(egl_display, 0);
    if (!egl_success)
    {
        print_error("Could not set zero time swapping (error code: %x)\n", eglGetError());
        return false;
    }

    return true;
} 

void cleanup_egl()
{
    eglTerminate(egl_display);
}

void egl_loop_step()
{
    MSG msg;
    while(PeekMessage(&msg, NULL, 0, 0, PM_REMOVE))
    {
        // Translate the message and dispatch it to WindowProc()
        TranslateMessage(&msg);
        DispatchMessage(&msg);

        if(msg.message == WM_QUIT)
        {
            print("QUIT!\n");
            break;
        }
    }
}
