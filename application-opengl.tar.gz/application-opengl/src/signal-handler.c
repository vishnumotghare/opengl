// SPDX-FileCopyrightText: 2023 Sahithyen Kanaganayagam <mail@sahithyen.com>
// SPDX-License-Identifier: MIT

#include "signal-handler.h"

#if defined(__linux__)
volatile sig_atomic_t sigint_triggered = 0;

static void sig_handler(int _)
{
    (void)_;
    sigint_triggered = 1;
}
#else
int sigint_triggered = 0;
#endif

void initialize_signal_handler()
{
#if defined(__linux__)
    signal(SIGINT, sig_handler);
#endif
}
