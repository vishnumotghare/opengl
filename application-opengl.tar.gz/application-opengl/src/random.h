// SPDX-FileCopyrightText: 2023 Sahithyen Kanaganayagam <mail@sahithyen.com>
// SPDX-License-Identifier: MIT

#pragma once

#if !defined(_WIN32_WCE)
#include <math.h>
#endif

void initialize_random();
void reset_random();
float get_random_float();
int32_t get_random_fixed16();
