// SPDX-FileCopyrightText: 2023 Sahithyen Kanaganayagam <mail@sahithyen.com>
// SPDX-License-Identifier: MIT

#pragma once

#if !defined(_WIN32_WCE)
#include <time.h>
#include <stdint.h>
#include <stdbool.h>
#else
#if !defined(_STDINT_H)
// This file acts as a drop in if the system/compiler does not has a stdint.h
#  define _STDINT_H

typedef signed    char    int8_t;
typedef signed   short    int16_t;
typedef signed     int    int32_t;
// #  if defined(_MSC_VER)
// typedef signed __int64    int64_t;
// #  else
typedef signed long long  int64_t;
// #  endif

typedef unsigned    char  uint8_t;
typedef unsigned   short  uint16_t;
typedef unsigned     int  uint32_t;
// #  if defined(_MSC_VER)
// typedef unsigned __int64  uint64_t;
// #  else
typedef unsigned long long uint64_t;
// #  endif


typedef int bool;
#define true 1
#define false 0

#endif //#if !defined(_STDINT_H)

#endif

#if defined(__linux__)
int print(const char *format, ...);
int print_error(const char *format, ...);
int64_t difftimespec_ns(const struct timespec after, const struct timespec before);
#else
#define print printf_s
#define print_error printf_s

int64_t difftimespec_ns(uint64_t after, uint64_t before);
#endif
float from_fixed(int32_t value);
int32_t to_fixed16(float value);
#define MS_IN_NS (uint64_t)1000000l
#define SEC_IN_NS (uint64_t)1000000000l
#define PI 3.14159265359

#ifdef NIGHTMARE_USE_GLES2
#include <GLES2/gl2.h>

bool create_program(GLuint *program, const GLchar *vertex_source, const GLchar *fragment_source);
bool link_program(GLuint program);
GLuint load_shader(const GLchar *shader_source, GLenum type);
#endif