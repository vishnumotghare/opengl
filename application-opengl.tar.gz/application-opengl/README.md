Linux Build

To build for Linux follow the steps below from a terminal:

Run deploy.sh

# ./deploy.sh
