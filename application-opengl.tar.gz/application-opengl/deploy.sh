#!/bin/bash

top_dir=$(realpath $(dirname $0))


# Fixed for now
build_dir="$top_dir/_build"
install_dir="$top_dir/_install"

cmake -B$build_dir -G "Unix Makefiles" -DCMAKE_BUILD_TYPE=Debug -DCMAKE_INSTALL_PREFIX:FILEPATH=$install_dir

if [ "$?" -ne 0 ]; then
    echo "configure failed"
    exit 1
fi

cmake --build $build_dir --config Debug --target install --clean-first

if [ "$?" -ne 0 ]; then
    echo "build failed"
    exit 1
fi

cmake -B$build_dir -G "Unix Makefiles" -DCMAKE_BUILD_TYPE=Release -DCMAKE_INSTALL_PREFIX:FILEPATH=$install_dir

if [ "$?" -ne 0 ]; then
    echo "configure failed"
    exit 1
fi

cmake --build $build_dir --config Release --target install --clean-first

if [ "$?" -ne 0 ]; then
    echo "build failed"
    exit 1
fi

if [ "$?" -ne 0 ]; then
    echo "deploy to device failed"
    exit 1
fi

exit 0
